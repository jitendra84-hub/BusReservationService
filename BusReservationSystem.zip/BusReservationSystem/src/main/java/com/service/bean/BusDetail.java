package com.service.bean;

public class BusDetail {

	
	public static final String indentity = "Reserve";

	private int id;
	private int busNumber;
	private String operatorName;
	private float departureTime;
	private float arrivalTime;
	private int duration;
	private double price;
	private int resultCount;
	

	public BusDetail(int busNumber, String operatorName, float departureTime, float arrivalTime, int duration,double price) {
		
		super();
		this.busNumber = busNumber;
		this.operatorName = operatorName;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.duration = duration;
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getBusNumber() {
		return busNumber;
	}

	public void setBusNumber(int busNumber) {
		this.busNumber = busNumber;
	}

	public String getOperatorName() {
		return operatorName;
	}

	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}

	public float getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(float departureTime) {
		this.departureTime = departureTime;
	}

	public float getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(float arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getResultCount() {
		return resultCount;
	}

	public void setResultCount(int resultCount) {
		this.resultCount = resultCount;
	}

	public static String getIndentity() {
		return indentity;
	}

}
