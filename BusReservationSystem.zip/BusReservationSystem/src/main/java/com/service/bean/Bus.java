package com.service.bean;

public class Bus {

	private String srcCity;
	private String destCity;
	private String departureTime;
	private String arrivalTime;

	public Bus(String src, String dest, String dept){
		
		this.srcCity=src;
		this.destCity=dest;
		this.departureTime=dept;
	}
	
	public String getSrcCity() {
		return srcCity;
	}
	public void setSrcCity(String srcCity) {
		this.srcCity = srcCity;
	}
	public String getDestCity() {
		return destCity;
	}
	public void setDestCity(String destCity) {
		this.destCity = destCity;
	}
	public String getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}
	public String getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	
}
