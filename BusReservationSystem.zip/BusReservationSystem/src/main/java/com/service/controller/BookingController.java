package com.service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bus.services.BusService;
import com.bus.services.request.SearchRequest;
import com.service.bean.BusDetail;

@RestController
public class BookingController {

	
	 @Autowired BusService busService;
	 
	 @RequestMapping("/all")
	 public List<String> findAllCity(){
		 return busService.getAllCity();
	 }
	 
	 @RequestMapping("/searchAll")
	 public List<BusDetail> findByCity(@RequestBody SearchRequest searchRequest){
		 return busService.getAvailableTripSchedules(searchRequest);
	 }
	
	 @RequestMapping("/sortByOperator")
	 public List<BusDetail> sortByOperator(@RequestBody SearchRequest searchRequest) {
		 return  busService.sortScheduleByOperator(searchRequest);
 		 
	 }

	 @RequestMapping("/sortByArrivalTime")
	 public List<BusDetail> sortByArrivalTime(@RequestBody SearchRequest searchRequest) {
		 return  busService.sortScheduleByArrivalTime(searchRequest);
 		 
	 }
	 
	 @RequestMapping("/sortByDuration")
	 public List<BusDetail> sortByDuration(@RequestBody SearchRequest searchRequest) {
		 return  busService.sortScheduleByDuration(searchRequest);
 		 
	 }
	
	 @RequestMapping("/sortByDeptTime")
	 public List<BusDetail> sortByDeptTime(@RequestBody SearchRequest searchRequest) {
		 return  busService.sortScheduleByDepartureTime(searchRequest);
 		 
	 }

}
