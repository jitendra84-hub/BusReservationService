package com.service.utility;

import java.util.Comparator;

import com.service.bean.BusDetail;

public class BusScheduleSortByDepartureTime implements Comparator<BusDetail> {

	@Override
	public int compare(BusDetail b1, BusDetail b2) {
		
		return b1.getDepartureTime()< b2.getDepartureTime()? -1 : b1.getDepartureTime()> b2.getDepartureTime()? 1 : 0;
		
	}
}
