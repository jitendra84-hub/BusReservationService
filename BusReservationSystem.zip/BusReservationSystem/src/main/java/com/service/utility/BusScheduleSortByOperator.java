package com.service.utility;

import java.util.Comparator;

import com.service.bean.BusDetail;

public class BusScheduleSortByOperator implements Comparator<BusDetail> {

	@Override
	public int compare(BusDetail b1, BusDetail b2) {
		// TODO Auto-generated method stub
		return b1.getOperatorName().compareTo(b2.getOperatorName());
		
	}

}
