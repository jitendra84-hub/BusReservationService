package com.bus.services;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Component;

import com.bus.services.request.BookingRequest;
import com.bus.services.request.SearchRequest;
import com.service.bean.BusDetail;
import com.service.dto.BusDto;
import com.service.utility.BusScheduleSortByArrivalTime;
import com.service.utility.BusScheduleSortByDepartureTime;
import com.service.utility.BusScheduleSortByDuration;
import com.service.utility.BusScheduleSortByOperator;


@Component
public class BusServiceImpl implements BusService {

	@Override
	public List<String> getAllCity(){
		return Repository.getAllCity();
	}
	
	@Override
	public List<BusDetail> getAvailableTripSchedules(SearchRequest searchRequest) {
		return Repository.getAllBusServices(searchRequest);       
	}

	@Override
	public List<BusDetail> sortScheduleByOperator(SearchRequest searchRequest) {
		// TODO Auto-generated method stub
		List<BusDetail> busList = Repository.getAllBusServices(searchRequest);
		Collections.sort(busList, new BusScheduleSortByOperator());
		return busList;		
	
	}

	@Override
	public List<BusDetail> sortScheduleByDepartureTime(SearchRequest searchRequest) {
		// TODO Auto-generated method stub
		List<BusDetail> busList = Repository.getAllBusServices(searchRequest);
		Collections.sort(busList, new BusScheduleSortByDepartureTime());
		return busList;		
	}


	@Override
	public List<BusDetail> sortScheduleByArrivalTime(SearchRequest searchRequest) {
		// TODO Auto-generated method stub
		List<BusDetail> busList = Repository.getAllBusServices(searchRequest);
		Collections.sort(busList, new BusScheduleSortByArrivalTime());
		return busList;		
	}


	@Override
	public List<BusDetail> sortScheduleByDuration(SearchRequest searchRequest) {
		// TODO Auto-generated method stub
		List<BusDetail> busList = Repository.getAllBusServices(searchRequest);
		Collections.sort(busList, new BusScheduleSortByDuration());
		return busList;		
	}
	

	@Override
	public BusDto bookTicket(BookingRequest bookingRequest) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
