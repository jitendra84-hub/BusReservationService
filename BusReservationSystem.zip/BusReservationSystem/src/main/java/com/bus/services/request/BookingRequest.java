package com.bus.services.request;

public class BookingRequest {

}
