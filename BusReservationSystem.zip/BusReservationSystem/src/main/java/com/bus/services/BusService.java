package com.bus.services;

import java.util.List;

import com.bus.services.request.BookingRequest;
import com.bus.services.request.SearchRequest;
import com.service.bean.BusDetail;
import com.service.dto.BusDto;

public interface BusService {
	
	public List<String> getAllCity();
	// Bus Availibility methods
    List<BusDetail> getAvailableTripSchedules(SearchRequest searchRequest);
    
   // Book Ticket method
    BusDto bookTicket(BookingRequest bookingRequest);

    //Sort  methods
   
    List<BusDetail> sortScheduleByOperator(SearchRequest searchRequest);

	List<BusDetail> sortScheduleByDepartureTime(SearchRequest searchRequest);

	List<BusDetail> sortScheduleByArrivalTime(SearchRequest searchRequest);

	List<BusDetail> sortScheduleByDuration(SearchRequest searchRequest);
}
