package com.bus.services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bus.constants.Travell;
import com.bus.reader.FileDataReader;
import com.bus.reader.FileReaderFactory;
import com.bus.services.request.SearchRequest;
import com.service.bean.BusDetail;
import com.service.dto.BusDto;

public class Repository {

	static Map<String,String> sourceToDestinationMap = new HashMap<>();
	static FileReaderFactory factory=new FileReaderFactory();
	static final String FILE_PATH = "./busData.csv";
	public static String BANGKOK="Bangkok";
	public static String PATTAYA="Pattaya";
	public static String PHUKET="Phuket";
	public static String KOHTAO="Koh Tao";
	public static String KRABI="Krabi";
	
	static {
		
		sourceToDestinationMap.put(BANGKOK,PHUKET);
		sourceToDestinationMap.put(BANGKOK,PATTAYA);
		sourceToDestinationMap.put(BANGKOK,PHUKET);
		sourceToDestinationMap.put(BANGKOK,KOHTAO);
		
		sourceToDestinationMap.put(KRABI,BANGKOK);
		sourceToDestinationMap.put(KRABI,PATTAYA);
		sourceToDestinationMap.put(KRABI,PHUKET);
		sourceToDestinationMap.put(KRABI,KOHTAO);
		
		sourceToDestinationMap.put(PHUKET,KRABI);
		sourceToDestinationMap.put(PHUKET,BANGKOK);
		sourceToDestinationMap.put(PHUKET,PATTAYA);
		sourceToDestinationMap.put(PHUKET,KOHTAO);
		
		sourceToDestinationMap.put(PATTAYA,KRABI);
		sourceToDestinationMap.put(PATTAYA,BANGKOK);
		sourceToDestinationMap.put(PATTAYA,PHUKET);
		sourceToDestinationMap.put(PATTAYA,KOHTAO);
		
		sourceToDestinationMap.put(KOHTAO,PHUKET);
		sourceToDestinationMap.put(KOHTAO,KRABI);
		
	}
	
	public static List<String> getAllCity(){
		
		 List<String> listOfCity = new ArrayList<String>();
		 listOfCity.add("Bangkok");
		 listOfCity.add("Chiang Mai");
		 listOfCity.add("Krabi");
		 listOfCity.add("Pattaya");
		 listOfCity.add("Phuket");
		 listOfCity.add("SuratThani");
		 listOfCity.add("koh Samui");
		 listOfCity.add("Koh Tao");

		 return listOfCity;
	}
	

	public static List<BusDetail> getAllBusServices(SearchRequest searchRequest){
		
		List<BusDetail> listBus=null;

		if(searchRequest.getSrcCity()!=null && searchRequest.getDestCity()!=null) {
			boolean status= isServiceAvailableFromSourceToDestination(searchRequest.getSrcCity());
			if(status) {
				  listBus=getAllAvailableBusDetails(searchRequest);
			}
		}
		return listBus;
	}


	private static List<BusDetail> getAllAvailableBusDetails(SearchRequest searchRequest) {
		// TODO Auto-generated method stub
		// needs to optimize more..when get time
		String DEST=searchRequest.getDestCity();
		
		List<BusDetail> listBus =null;
	    
		 switch(DEST) {
		 
			case("Phuket"):
				listBus = getBusService1(searchRequest);
			    break;
	        case("Bangkok"):
	        	listBus =  getBusService2(searchRequest);
	            break;
	     	case("Pattaya"):
	     		listBus =  getBusService3(searchRequest);
	     	    break;
	     	case("Koh Tao"):
	     		listBus = getBusService4(searchRequest);
	     	    break;
	        case("Krabi"):
	        	listBus = getBusService5(searchRequest);
	            break;
	        default:  
                 System.out.println("No Service Availabe");  
                 break; 
			}
		return listBus;
	}
	
   private static List<BusDetail> getBusService1(SearchRequest searchRequest) {
		
	   //readDataFeedFile() 
	   // Other option for the reading data feed
		List<BusDetail> listBus =new ArrayList<>();
		
		if(searchRequest.getDepartureTime().equalsIgnoreCase("13")) {
		
		listBus.add(new BusDetail(101,"AIR",13,15,2,200));
		listBus.add(new BusDetail(103,"GREEN",13,15,2,200));
		
		}else if(searchRequest.getDepartureTime().equalsIgnoreCase("16")) {
		listBus.add(new BusDetail(101,"AIR",16,18,2,200));
		listBus.add(new BusDetail(103,"GREEN",16,18,2,200));
		
		} else if (searchRequest.getDepartureTime().equalsIgnoreCase("14")) {
		 listBus.add(new BusDetail(108,"LOTUS",14,16,2,200));
		 listBus.add(new BusDetail(111,"LOTUS",14,16,2,200));
	   }
		return listBus;
	}
	
   private static List<BusDetail> getBusService2(SearchRequest searchRequest) {

	   //readDataFeedFile() 
	   // Other option for the reading data feed
		List<BusDetail> listBus =new ArrayList<>();
		
		listBus.add(new BusDetail(201,"AIR",14,17,3,300));
		listBus.add(new BusDetail(105,"GREEN",14,19,5,500));
		listBus.add(new BusDetail(109,"LOTUS",12,15,3,300));
		listBus.add(new BusDetail(211,"LOTUS",14,16,2,200));
		
		return listBus;			
	}
	
    private static List<BusDetail> getBusService3(SearchRequest searchRequest) {
		
 	   //readDataFeedFile() 
 	   // Other option for the reading data feed
    	List<BusDetail> listBus =new ArrayList<>();
		
		listBus.add(new BusDetail(302,"AIR",15,16,2,100));	
		listBus.add(new BusDetail(104,"GREEN",16,20,4,300));
		listBus.add(new BusDetail(106,"LOTUS",13,18,5,500));
		listBus.add(new BusDetail(311,"LOTUS",14,16,2,200));
		
		return listBus;			
	}
	
    private static List<BusDetail> getBusService4(SearchRequest searchRequest) {
		
 	   //readDataFeedFile() 
 	   // Other option for the reading data feed
    	List<BusDetail> listBus =new ArrayList<>();

    	listBus.add(new BusDetail(412,"AIR",13,18,5,500));
		listBus.add(new BusDetail(403,"GREEN",12,16,4,400));
		return listBus;			
	}
	
    private static List<BusDetail> getBusService5(SearchRequest searchRequest) {
		

 	   //readDataFeedFile() 
 	   // Other option for the reading data feed
		List<BusDetail> listBus =new ArrayList<>();
		
		listBus.add(new BusDetail(512,"AIR",13,15,3,300));
		listBus.add(new BusDetail(503,"GREEN",16,18,2,200));
		listBus.add(new BusDetail(508,"LOTUS",14,16,2,200));
		listBus.add(new BusDetail(510,"LOTUS",16,20,4,400));
		
		return listBus;			
	}
	
    
	private static boolean isServiceAvailableFromSourceToDestination(String sourceCity) {
		// TODO Auto-generated method stub
	  boolean status = false;	
	  String destination =	sourceToDestinationMap.get(sourceCity);
	 
	  if(destination!=null) {
		  status=true;
	  }else {
		  System.out.println("No Service is availbe on this route");
	  }
	return status;
	 
	}
	
	
	private static BusDto readDataFeedFile() {
		
		BusDto busDto=new BusDto();
		FileDataReader fileReader=factory.getFileReader("CSV");
		
		try {
			fileReader.readFile(FILE_PATH,busDto);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return busDto;
	}
}
