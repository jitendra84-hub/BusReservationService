package com.bus.reader;

import java.io.IOException;

import com.service.dto.BusDto;

public abstract class FileDataReader {

	public abstract void readFile(String Path, BusDto busData) throws IOException;
	
}
