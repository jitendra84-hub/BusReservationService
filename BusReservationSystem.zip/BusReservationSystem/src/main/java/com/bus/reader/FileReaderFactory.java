package com.bus.reader;

public class FileReaderFactory {

	public FileDataReader getFileReader(String fileType){  
	       
		   if(fileType == null){  
	         return null;  
	        }  
	       if(fileType.equalsIgnoreCase("CSV")) {  
	             return new CsvFileReader();  
	           }   
	       else if(fileType.equalsIgnoreCase("EXCEL")){  
	            return new ExcelFileReader();  
	        }   
	       else if(fileType.equalsIgnoreCase("XML")) {  
	            return new XmlFileReader();  
	       }
	       else if(fileType.equalsIgnoreCase("JSON")) {  
	          return new JsonFileReader();  
	    }
	       
	  return null;  
	 }  
}
