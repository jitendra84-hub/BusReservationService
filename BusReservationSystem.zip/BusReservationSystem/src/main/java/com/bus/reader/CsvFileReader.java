package com.bus.reader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import com.service.dto.BusDto;

public class CsvFileReader extends FileDataReader {

	String line = "";  
	String splitBy = ",";  
	
	@Override
	public void readFile(String Path, BusDto busDto) throws IOException {
		// TODO Auto-generated method stub
		
		BufferedReader br = new BufferedReader(new FileReader(Path));  
		while ((line = br.readLine()) != null)   //returns a Boolean value  
		{  
		String[] feedData = line.split(splitBy);    // use comma as separator  
		for(String s: feedData) {
			
			busDto.setBusNumber(s);
			busDto.setSourceCity(s);
			busDto.setDestinationCity(s);
			busDto.setBusNumber(s);
			busDto.setBusNumber(s);
		}
	  }  
	}
}
