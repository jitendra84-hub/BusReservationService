package com.bus.reader;

import java.io.IOException;

import com.service.dto.BusDto;

public class ExcelFileReader extends FileDataReader {

	@Override
	public void readFile(String Path, BusDto busData) throws IOException {
		// TODO Auto-generated method stub

	}

}
