package com.bus.services;

import static org.junit.Assert.assertEquals;
import java.util.List;
import org.junit.Before;
import org.junit.Test;

import com.bus.services.request.SearchRequest;
import com.service.bean.BusDetail;

public class BusServiceImplTest {

	private BusService busService;
	private SearchRequest searchRequest;

	@Before
	public void setUp() throws Exception {
	
		busService = new BusServiceImpl();
	   //Set Dummy Data
		searchRequest=new SearchRequest();
		searchRequest.setSrcCity("Bangkok");
		searchRequest.setDestCity("Phuket");
		searchRequest.setDepartureTime("13");
		searchRequest.setArrivalTime("15");
		
	}

	 
	@Test
	public void testGetAvailableTripSchedules() {
		
		List<BusDetail> busList=busService.getAvailableTripSchedules(searchRequest);
		assertEquals(13.0,busList.get(0).getDepartureTime(),13.0);
		
	}

	@Test
	public void testSortScheduleByOperator() {
		List<BusDetail> busList=busService.sortScheduleByOperator(searchRequest);
		assertEquals(13.0,busList.get(0).getDepartureTime(),13.0);
	}

	@Test
	public void testSortScheduleByDepartureTime() {
		List<BusDetail> busList=busService.sortScheduleByDepartureTime(searchRequest);
		assertEquals(13.0,busList.get(0).getDepartureTime(),13.0);
	}

	@Test
	public void testSortScheduleByArrivalTime() {
		List<BusDetail> busList=busService.sortScheduleByArrivalTime(searchRequest);
		assertEquals(13.0,busList.get(0).getDepartureTime(),13.0);
	}

	@Test
	public void testSortScheduleByDuration() {
		List<BusDetail> busList=busService.sortScheduleByDuration(searchRequest);
		assertEquals(13.0,busList.get(0).getDepartureTime(),13.0);
	}
	
}
